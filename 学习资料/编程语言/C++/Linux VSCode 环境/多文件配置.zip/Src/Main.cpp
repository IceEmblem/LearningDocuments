#include <iostream>
#include "./Pans/Pan.h"

int main()
{
    Pan pan(5);
    std::cout << pan.GetMoney() << std::endl;

    std::cout << "hello world"<< std::endl;

    return 0;
}