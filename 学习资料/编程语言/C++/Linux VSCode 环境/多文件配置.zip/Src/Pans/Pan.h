#ifndef Pan_H
#define Pan_H

class Pan
{
private:
    int _money;
public:
    Pan(int money):_money(money){};

    int GetMoney();
};

#endif