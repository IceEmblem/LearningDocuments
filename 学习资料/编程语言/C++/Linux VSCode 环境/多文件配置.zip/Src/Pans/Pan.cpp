#include "./Pan.h"

int Pan::GetMoney(){
    return _money;
}