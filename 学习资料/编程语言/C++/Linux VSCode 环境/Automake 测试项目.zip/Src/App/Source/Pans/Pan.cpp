#include "Src/App/Include/Pan.h"

int Pan::GetMoney(){
    return _money;
}