#include <iostream>
#include "Src/App/Include/Pan.h"
#include "Src/Module1/Include/Color.h"

int main()
{
    Pan pan(5);
    std::cout << pan.GetMoney() << std::endl;

    Color color(1);
    std::cout << color.GetValue() << std::endl;

    std::cout << "hello world"<< std::endl;

    return 0;
}