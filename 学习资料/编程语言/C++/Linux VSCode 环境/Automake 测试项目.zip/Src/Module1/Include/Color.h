#ifndef Color_H
#define Color_H

class Color
{
private:
    int _value;
public:
    Color(int value):_value(value){};

    int GetValue();
};

#endif