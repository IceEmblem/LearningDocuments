#include "Src/Module1/Include/Color.h"

int Color::GetValue(){
    return _value;
}