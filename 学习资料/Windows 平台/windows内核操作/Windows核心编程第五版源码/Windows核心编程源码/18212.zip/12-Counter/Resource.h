//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Counter.rc
//
#define IDC_STATIC              (-1)     // all static controls
#define IDD_COUNTER                     101
#define IDI_COUNTER                     102
#define IDC_FIBER                       1000
#define IDC_ANSWER                      1001
#define IDC_COUNT                       1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
