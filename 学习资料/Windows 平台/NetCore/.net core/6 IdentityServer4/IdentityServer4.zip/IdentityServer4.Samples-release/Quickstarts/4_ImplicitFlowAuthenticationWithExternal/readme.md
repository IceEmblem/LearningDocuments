# Quickstart #4: Adding external Authentication

This quickstart adds support for Google authentication.

## Tutorial

The tutorial that goes along with this sample can be found here [Adding Support for External Authentication](http://docs.identityserver.io/en/release/quickstarts/4_external_authentication.html)
